-- Semana 07: ultima barreira contra matricula ATIVA duplicada.
-- O Service ja valida a regra; este indice protege o banco contra
-- duas requisicoes simultaneas que passem pela validacao ao mesmo tempo.
CREATE UNIQUE INDEX uk_matricula_ativa_aluno_curso
    ON tb_matricula (aluno_id, curso_id)
    WHERE status = 'ATIVA';
