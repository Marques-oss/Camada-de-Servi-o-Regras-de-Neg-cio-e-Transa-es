CREATE TABLE tb_curso
(
    id            BIGSERIAL PRIMARY KEY,
    nome          VARCHAR(100) NOT NULL,
    carga_horaria INTEGER      NOT NULL
);
