-- Preserva o campo "idade" criado na Semana 04 (DTO + Validation).
-- A V1 ja foi aplicada e NAO e editada: toda mudanca de schema gera nova versao.
-- A coluna e opcional no banco; a obrigatoriedade e garantida na API pelo DTO.
ALTER TABLE tb_aluno
    ADD COLUMN idade INTEGER;
