-- Semana 06: integridade referencial entre matricula, aluno e curso.
ALTER TABLE tb_matricula
    ADD CONSTRAINT fk_matricula_aluno
        FOREIGN KEY (aluno_id)
            REFERENCES tb_aluno (id);

ALTER TABLE tb_matricula
    ADD CONSTRAINT fk_matricula_curso
        FOREIGN KEY (curso_id)
            REFERENCES tb_curso (id);
