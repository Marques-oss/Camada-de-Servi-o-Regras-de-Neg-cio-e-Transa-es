-- Semana 05: aluno_id e curso_id tratados como identificadores simples.
-- As chaves estrangeiras entram na V5 (Semana 06).
CREATE TABLE tb_matricula
(
    id       BIGSERIAL PRIMARY KEY,
    aluno_id BIGINT      NOT NULL,
    curso_id BIGINT      NOT NULL,
    status   VARCHAR(30) NOT NULL
);
