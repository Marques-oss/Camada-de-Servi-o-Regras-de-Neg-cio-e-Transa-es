package br.edu.univest.academico.dto;

import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;

/**
 * O cliente envia apenas IDs; o Service busca as entidades.
 * Nao ha campo "status": toda matricula nasce ATIVA e muda de estado
 * apenas pelas operacoes de dominio (trancar, cancelar, concluir).
 */
public class MatriculaRequestDTO {

    @NotNull(message = "O id do aluno é obrigatório")
    @Positive(message = "O id do aluno deve ser positivo")
    private Long alunoId;

    @NotNull(message = "O id do curso é obrigatório")
    @Positive(message = "O id do curso deve ser positivo")
    private Long cursoId;

    public MatriculaRequestDTO() {
    }

    public Long getAlunoId() { return alunoId; }
    public void setAlunoId(Long alunoId) { this.alunoId = alunoId; }

    public Long getCursoId() { return cursoId; }
    public void setCursoId(Long cursoId) { this.cursoId = cursoId; }
}
