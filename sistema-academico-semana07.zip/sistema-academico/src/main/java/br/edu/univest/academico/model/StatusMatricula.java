package br.edu.univest.academico.model;

/**
 * Estados possiveis de uma matricula.
 * Regra do dominio: somente uma matricula ATIVA pode mudar de estado.
 */
public enum StatusMatricula {
    ATIVA,
    TRANCADA,
    CANCELADA,
    CONCLUIDA;

    /** ATIVA -> TRANCADA | CANCELADA | CONCLUIDA. Qualquer outra transicao e proibida. */
    public boolean podeTransitarPara(StatusMatricula destino) {
        return this == ATIVA && destino != ATIVA;
    }
}
