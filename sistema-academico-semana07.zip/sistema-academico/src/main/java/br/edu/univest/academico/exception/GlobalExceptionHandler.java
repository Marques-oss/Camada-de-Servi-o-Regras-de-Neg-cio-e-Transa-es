package br.edu.univest.academico.exception;

import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Traduz excecoes em respostas HTTP coerentes. Os Services lancam excecoes de dominio
 * e o Controller continua "fino": nao precisa de if/else para montar status de erro.
 */
@RestControllerAdvice
public class GlobalExceptionHandler {

    /** @Valid reprovou o corpo da requisicao -> 400 com a lista de campos invalidos. */
    @ExceptionHandler(MethodArgumentNotValidException.class)
    public ResponseEntity<ErroValidacaoDTO> tratarValidacao(MethodArgumentNotValidException ex) {
        Map<String, String> campos = new LinkedHashMap<>();
        for (FieldError erro : ex.getBindingResult().getFieldErrors()) {
            campos.put(erro.getField(), erro.getDefaultMessage());
        }
        ErroValidacaoDTO corpo = new ErroValidacaoDTO(
                HttpStatus.BAD_REQUEST.value(),
                "Erro de validação nos dados enviados",
                campos);
        return ResponseEntity.badRequest().body(corpo);
    }

    /** JSON malformado ou valor que nao existe no enum (ex.: status invalido) -> 400. */
    @ExceptionHandler(HttpMessageNotReadableException.class)
    public ResponseEntity<ErroDTO> tratarCorpoIlegivel(HttpMessageNotReadableException ex) {
        return resposta(HttpStatus.BAD_REQUEST, "Requisição inválida",
                "Corpo da requisição ilegível ou com valor não reconhecido.");
    }

    /** Aluno/curso/matricula inexistente -> 404. */
    @ExceptionHandler(RecursoNaoEncontradoException.class)
    public ResponseEntity<ErroDTO> tratarNaoEncontrado(RecursoNaoEncontradoException ex) {
        return resposta(HttpStatus.NOT_FOUND, "Recurso não encontrado", ex.getMessage());
    }

    /** Regra de negocio violada -> 422. */
    @ExceptionHandler(RegraNegocioException.class)
    public ResponseEntity<ErroDTO> tratarRegraNegocio(RegraNegocioException ex) {
        return resposta(HttpStatus.UNPROCESSABLE_ENTITY, "Regra de negócio violada", ex.getMessage());
    }

    /** Ultima barreira: restricao do banco (UNIQUE/FK) violada, ex.: duas requisicoes simultaneas -> 409. */
    @ExceptionHandler(DataIntegrityViolationException.class)
    public ResponseEntity<ErroDTO> tratarIntegridade(DataIntegrityViolationException ex) {
        return resposta(HttpStatus.CONFLICT, "Conflito de integridade",
                "A operação viola uma restrição de integridade dos dados (registro duplicado ou em uso).");
    }

    private ResponseEntity<ErroDTO> resposta(HttpStatus status, String erro, String mensagem) {
        return ResponseEntity.status(status).body(new ErroDTO(status.value(), erro, mensagem));
    }
}
