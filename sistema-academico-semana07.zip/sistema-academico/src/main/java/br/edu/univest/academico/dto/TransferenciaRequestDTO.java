package br.edu.univest.academico.dto;

import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;

/** Corpo do POST /api/matriculas/{id}/transferir. */
public class TransferenciaRequestDTO {

    @NotNull(message = "O id do novo curso é obrigatório")
    @Positive(message = "O id do novo curso deve ser positivo")
    private Long novoCursoId;

    public TransferenciaRequestDTO() {
    }

    public Long getNovoCursoId() { return novoCursoId; }
    public void setNovoCursoId(Long novoCursoId) { this.novoCursoId = novoCursoId; }
}
