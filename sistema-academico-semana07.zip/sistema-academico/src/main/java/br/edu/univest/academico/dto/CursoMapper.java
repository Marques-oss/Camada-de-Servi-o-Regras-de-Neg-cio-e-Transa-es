package br.edu.univest.academico.dto;

import br.edu.univest.academico.model.Curso;

public final class CursoMapper {

    private CursoMapper() {
    }

    public static Curso toEntity(CursoRequestDTO dto) {
        Curso curso = new Curso();
        curso.setNome(dto.getNome());
        curso.setCargaHoraria(dto.getCargaHoraria());
        return curso;
    }

    public static CursoResponseDTO toResponseDTO(Curso curso) {
        return new CursoResponseDTO(curso.getId(), curso.getNome(), curso.getCargaHoraria());
    }
}
