package br.edu.univest.academico.controller;

import br.edu.univest.academico.dto.MatriculaMapper;
import br.edu.univest.academico.dto.MatriculaRequestDTO;
import br.edu.univest.academico.dto.MatriculaResponseDTO;
import br.edu.univest.academico.dto.TransferenciaRequestDTO;
import br.edu.univest.academico.model.Matricula;
import br.edu.univest.academico.service.MatriculaService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/api/matriculas")
@Tag(name = "Matrículas")
public class MatriculaController {

    private final MatriculaService service;

    public MatriculaController(MatriculaService service) {
        this.service = service;
    }

    @Operation(summary = "Listar matrículas (filtros opcionais: alunoId ou cursoId)")
    @GetMapping
    public ResponseEntity<List<MatriculaResponseDTO>> listar(
            @RequestParam(required = false) Long alunoId,
            @RequestParam(required = false) Long cursoId) {

        List<Matricula> matriculas;
        if (alunoId != null) {
            matriculas = service.listarPorAluno(alunoId);
        } else if (cursoId != null) {
            matriculas = service.listarPorCurso(cursoId);
        } else {
            matriculas = service.listar();
        }
        return ResponseEntity.ok(matriculas.stream().map(MatriculaMapper::toResponseDTO).toList());
    }

    @Operation(summary = "Consultar matrícula por ID")
    @GetMapping("/{id}")
    public ResponseEntity<MatriculaResponseDTO> consultar(@PathVariable Long id) {
        return ResponseEntity.ok(MatriculaMapper.toResponseDTO(service.consultar(id)));
    }

    @Operation(summary = "Matricular aluno em curso (nasce ATIVA)")
    @PostMapping
    public ResponseEntity<MatriculaResponseDTO> matricular(@Valid @RequestBody MatriculaRequestDTO dto) {
        Matricula matricula = service.matricular(dto.getAlunoId(), dto.getCursoId());
        return ResponseEntity.status(HttpStatus.CREATED).body(MatriculaMapper.toResponseDTO(matricula));
    }

    @Operation(summary = "Atualizar aluno/curso de uma matrícula ATIVA")
    @PutMapping("/{id}")
    public ResponseEntity<MatriculaResponseDTO> atualizar(@PathVariable Long id,
                                                          @Valid @RequestBody MatriculaRequestDTO dto) {
        Matricula matricula = service.atualizar(id, dto.getAlunoId(), dto.getCursoId());
        return ResponseEntity.ok(MatriculaMapper.toResponseDTO(matricula));
    }

    @Operation(summary = "Trancar matrícula (ATIVA -> TRANCADA)")
    @PatchMapping("/{id}/trancar")
    public ResponseEntity<MatriculaResponseDTO> trancar(@PathVariable Long id) {
        return ResponseEntity.ok(MatriculaMapper.toResponseDTO(service.trancarMatricula(id)));
    }

    @Operation(summary = "Cancelar matrícula (ATIVA -> CANCELADA)")
    @PatchMapping("/{id}/cancelar")
    public ResponseEntity<MatriculaResponseDTO> cancelar(@PathVariable Long id) {
        return ResponseEntity.ok(MatriculaMapper.toResponseDTO(service.cancelarMatricula(id)));
    }

    @Operation(summary = "Concluir matrícula (ATIVA -> CONCLUIDA)")
    @PatchMapping("/{id}/concluir")
    public ResponseEntity<MatriculaResponseDTO> concluir(@PathVariable Long id) {
        return ResponseEntity.ok(MatriculaMapper.toResponseDTO(service.concluirMatricula(id)));
    }

    @Operation(summary = "Transferir matrícula para outro curso (cancela a atual e cria nova, em uma transação)")
    @PostMapping("/{id}/transferir")
    public ResponseEntity<MatriculaResponseDTO> transferir(@PathVariable Long id,
                                                           @Valid @RequestBody TransferenciaRequestDTO dto) {
        Matricula nova = service.transferir(id, dto.getNovoCursoId());
        return ResponseEntity.status(HttpStatus.CREATED).body(MatriculaMapper.toResponseDTO(nova));
    }
}
