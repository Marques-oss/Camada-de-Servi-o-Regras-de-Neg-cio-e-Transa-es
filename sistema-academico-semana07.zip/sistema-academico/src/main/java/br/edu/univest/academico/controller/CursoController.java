package br.edu.univest.academico.controller;

import br.edu.univest.academico.dto.CursoMapper;
import br.edu.univest.academico.dto.CursoRequestDTO;
import br.edu.univest.academico.dto.CursoResponseDTO;
import br.edu.univest.academico.model.Curso;
import br.edu.univest.academico.service.CursoService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/api/cursos")
@Tag(name = "Cursos")
public class CursoController {

    private final CursoService service;

    public CursoController(CursoService service) {
        this.service = service;
    }

    @Operation(summary = "Listar todos os cursos")
    @GetMapping
    public ResponseEntity<List<CursoResponseDTO>> listar() {
        List<CursoResponseDTO> resposta = service.listar().stream()
                .map(CursoMapper::toResponseDTO)
                .toList();
        return ResponseEntity.ok(resposta);
    }

    @Operation(summary = "Consultar curso por ID")
    @GetMapping("/{id}")
    public ResponseEntity<CursoResponseDTO> consultar(@PathVariable Long id) {
        return ResponseEntity.ok(CursoMapper.toResponseDTO(service.consultar(id)));
    }

    @Operation(summary = "Cadastrar novo curso")
    @PostMapping
    public ResponseEntity<CursoResponseDTO> cadastrar(@Valid @RequestBody CursoRequestDTO dto) {
        Curso cadastrado = service.cadastrar(CursoMapper.toEntity(dto));
        return ResponseEntity.status(HttpStatus.CREATED).body(CursoMapper.toResponseDTO(cadastrado));
    }

    @Operation(summary = "Atualizar curso")
    @PutMapping("/{id}")
    public ResponseEntity<CursoResponseDTO> atualizar(@PathVariable Long id,
                                                      @Valid @RequestBody CursoRequestDTO dto) {
        Curso atualizado = service.atualizar(id, CursoMapper.toEntity(dto));
        return ResponseEntity.ok(CursoMapper.toResponseDTO(atualizado));
    }

    @Operation(summary = "Excluir curso (bloqueado se houver matrículas)")
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> excluir(@PathVariable Long id) {
        service.excluir(id);
        return ResponseEntity.noContent().build();
    }
}
