package br.edu.univest.academico.repository;

import br.edu.univest.academico.model.Matricula;
import br.edu.univest.academico.model.StatusMatricula;
import org.springframework.data.jpa.repository.EntityGraph;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

/**
 * O @EntityGraph carrega aluno e curso junto com a matricula em UMA consulta (JOIN),
 * evitando o problema N+1 e o LazyInitializationException ao montar o ResponseDTO.
 */
@Repository
public interface MatriculaRepository extends JpaRepository<Matricula, Long> {

    @Override
    @EntityGraph(attributePaths = {"aluno", "curso"})
    List<Matricula> findAll();

    @Override
    @EntityGraph(attributePaths = {"aluno", "curso"})
    Optional<Matricula> findById(Long id);

    @EntityGraph(attributePaths = {"aluno", "curso"})
    List<Matricula> findByAluno_Id(Long alunoId);

    @EntityGraph(attributePaths = {"aluno", "curso"})
    List<Matricula> findByCurso_Id(Long cursoId);

    // ---- regras de negocio ----
    boolean existsByAluno_IdAndCurso_IdAndStatus(Long alunoId, Long cursoId, StatusMatricula status);

    boolean existsByAluno_IdAndCurso_IdAndStatusAndIdNot(Long alunoId, Long cursoId, StatusMatricula status, Long id);

    // ---- regras de exclusao ----
    boolean existsByAluno_IdAndStatus(Long alunoId, StatusMatricula status);

    boolean existsByCurso_IdAndStatus(Long cursoId, StatusMatricula status);

    boolean existsByAluno_Id(Long alunoId);

    boolean existsByCurso_Id(Long cursoId);
}
