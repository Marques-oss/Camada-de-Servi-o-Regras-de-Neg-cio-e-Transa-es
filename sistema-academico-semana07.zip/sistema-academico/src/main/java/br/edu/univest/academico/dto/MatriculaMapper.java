package br.edu.univest.academico.dto;

import br.edu.univest.academico.model.Matricula;

public final class MatriculaMapper {

    private MatriculaMapper() {
    }

    public static MatriculaResponseDTO toResponseDTO(Matricula m) {
        return new MatriculaResponseDTO(
                m.getId(),
                m.getAluno().getId(),
                m.getAluno().getNome(),
                m.getCurso().getId(),
                m.getCurso().getNome(),
                m.getStatus());
    }
}
