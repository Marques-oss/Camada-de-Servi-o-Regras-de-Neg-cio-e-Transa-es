package br.edu.univest.academico.dto;

/** Contrato de saida de Aluno. Nao expoe a lista de matriculas (evita recursao no JSON). */
public class AlunoResponseDTO {

    private Long id;
    private String nome;
    private String email;
    private Integer idade;

    public AlunoResponseDTO() {
    }

    public AlunoResponseDTO(Long id, String nome, String email, Integer idade) {
        this.id = id;
        this.nome = nome;
        this.email = email;
        this.idade = idade;
    }

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getNome() { return nome; }
    public void setNome(String nome) { this.nome = nome; }

    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }

    public Integer getIdade() { return idade; }
    public void setIdade(Integer idade) { this.idade = idade; }
}
