package br.edu.univest.academico.controller;

import br.edu.univest.academico.dto.AlunoMapper;
import br.edu.univest.academico.dto.AlunoRequestDTO;
import br.edu.univest.academico.dto.AlunoResponseDTO;
import br.edu.univest.academico.model.Aluno;
import br.edu.univest.academico.service.AlunoService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/api/alunos")
@Tag(name = "Alunos")
public class AlunoController {

    private final AlunoService service;

    public AlunoController(AlunoService service) {
        this.service = service;
    }

    @Operation(summary = "Listar todos os alunos")
    @GetMapping
    public ResponseEntity<List<AlunoResponseDTO>> listar() {
        List<AlunoResponseDTO> resposta = service.listar().stream()
                .map(AlunoMapper::toResponseDTO)
                .toList();
        return ResponseEntity.ok(resposta);
    }

    @Operation(summary = "Consultar aluno por ID")
    @GetMapping("/{id}")
    public ResponseEntity<AlunoResponseDTO> consultar(@PathVariable Long id) {
        return ResponseEntity.ok(AlunoMapper.toResponseDTO(service.consultar(id)));
    }

    @Operation(summary = "Cadastrar novo aluno")
    @PostMapping
    public ResponseEntity<AlunoResponseDTO> cadastrar(@Valid @RequestBody AlunoRequestDTO dto) {
        Aluno cadastrado = service.cadastrar(AlunoMapper.toEntity(dto));
        return ResponseEntity.status(HttpStatus.CREATED).body(AlunoMapper.toResponseDTO(cadastrado));
    }

    @Operation(summary = "Atualizar aluno")
    @PutMapping("/{id}")
    public ResponseEntity<AlunoResponseDTO> atualizar(@PathVariable Long id,
                                                      @Valid @RequestBody AlunoRequestDTO dto) {
        Aluno atualizado = service.atualizar(id, AlunoMapper.toEntity(dto));
        return ResponseEntity.ok(AlunoMapper.toResponseDTO(atualizado));
    }

    @Operation(summary = "Excluir aluno (bloqueado se houver matrículas)")
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> excluir(@PathVariable Long id) {
        service.excluir(id);
        return ResponseEntity.noContent().build();
    }
}
