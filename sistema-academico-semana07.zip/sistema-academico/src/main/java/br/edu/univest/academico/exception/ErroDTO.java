package br.edu.univest.academico.exception;

import java.time.LocalDateTime;

/** Corpo padrao das respostas de erro (404, 422, 409...). */
public class ErroDTO {

    private final LocalDateTime timestamp = LocalDateTime.now();
    private final int status;
    private final String erro;
    private final String mensagem;

    public ErroDTO(int status, String erro, String mensagem) {
        this.status = status;
        this.erro = erro;
        this.mensagem = mensagem;
    }

    public LocalDateTime getTimestamp() { return timestamp; }
    public int getStatus() { return status; }
    public String getErro() { return erro; }
    public String getMensagem() { return mensagem; }
}
