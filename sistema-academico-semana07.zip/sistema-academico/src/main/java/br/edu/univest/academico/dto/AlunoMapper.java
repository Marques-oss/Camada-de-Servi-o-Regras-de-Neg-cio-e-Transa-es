package br.edu.univest.academico.dto;

import br.edu.univest.academico.model.Aluno;

public final class AlunoMapper {

    private AlunoMapper() {
    }

    public static Aluno toEntity(AlunoRequestDTO dto) {
        Aluno aluno = new Aluno();
        aluno.setNome(dto.getNome());
        aluno.setEmail(dto.getEmail());
        aluno.setIdade(dto.getIdade());
        return aluno;
    }

    public static AlunoResponseDTO toResponseDTO(Aluno aluno) {
        return new AlunoResponseDTO(aluno.getId(), aluno.getNome(), aluno.getEmail(), aluno.getIdade());
    }
}
