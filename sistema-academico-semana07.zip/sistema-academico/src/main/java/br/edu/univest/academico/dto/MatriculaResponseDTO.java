package br.edu.univest.academico.dto;

import br.edu.univest.academico.model.StatusMatricula;

/** Saida da matricula: informacoes uteis de aluno e curso, sem expor as entidades completas. */
public class MatriculaResponseDTO {

    private Long id;
    private Long alunoId;
    private String alunoNome;
    private Long cursoId;
    private String cursoNome;
    private StatusMatricula status;

    public MatriculaResponseDTO() {
    }

    public MatriculaResponseDTO(Long id, Long alunoId, String alunoNome,
                                Long cursoId, String cursoNome, StatusMatricula status) {
        this.id = id;
        this.alunoId = alunoId;
        this.alunoNome = alunoNome;
        this.cursoId = cursoId;
        this.cursoNome = cursoNome;
        this.status = status;
    }

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public Long getAlunoId() { return alunoId; }
    public void setAlunoId(Long alunoId) { this.alunoId = alunoId; }

    public String getAlunoNome() { return alunoNome; }
    public void setAlunoNome(String alunoNome) { this.alunoNome = alunoNome; }

    public Long getCursoId() { return cursoId; }
    public void setCursoId(Long cursoId) { this.cursoId = cursoId; }

    public String getCursoNome() { return cursoNome; }
    public void setCursoNome(String cursoNome) { this.cursoNome = cursoNome; }

    public StatusMatricula getStatus() { return status; }
    public void setStatus(StatusMatricula status) { this.status = status; }
}
