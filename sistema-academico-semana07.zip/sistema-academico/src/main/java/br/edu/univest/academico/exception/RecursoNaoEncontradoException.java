package br.edu.univest.academico.exception;

/** Recurso solicitado nao existe (ex.: aluno, curso ou matricula com o id informado). */
public class RecursoNaoEncontradoException extends RuntimeException {

    public RecursoNaoEncontradoException(String mensagem) {
        super(mensagem);
    }
}
