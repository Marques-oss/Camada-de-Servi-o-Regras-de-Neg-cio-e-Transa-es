package br.edu.univest.academico.exception;

/** Violacao de uma regra do dominio academico (ex.: matricula ativa duplicada). */
public class RegraNegocioException extends RuntimeException {

    public RegraNegocioException(String mensagem) {
        super(mensagem);
    }
}
