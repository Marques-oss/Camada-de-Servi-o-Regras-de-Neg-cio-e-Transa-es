package br.edu.univest.academico.service;

import br.edu.univest.academico.exception.RecursoNaoEncontradoException;
import br.edu.univest.academico.exception.RegraNegocioException;
import br.edu.univest.academico.model.Curso;
import br.edu.univest.academico.model.StatusMatricula;
import br.edu.univest.academico.repository.CursoRepository;
import br.edu.univest.academico.repository.MatriculaRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
public class CursoService {

    private final CursoRepository repository;
    private final MatriculaRepository matriculaRepository;

    public CursoService(CursoRepository repository, MatriculaRepository matriculaRepository) {
        this.repository = repository;
        this.matriculaRepository = matriculaRepository;
    }

    @Transactional(readOnly = true)
    public List<Curso> listar() {
        return repository.findAll();
    }

    @Transactional(readOnly = true)
    public Curso consultar(Long id) {
        return buscar(id);
    }

    @Transactional
    public Curso cadastrar(Curso curso) {
        return repository.save(curso);
    }

    @Transactional
    public Curso atualizar(Long id, Curso dados) {
        Curso existente = buscar(id);
        existente.setNome(dados.getNome());
        existente.setCargaHoraria(dados.getCargaHoraria());
        return existente; // dirty checking
    }

    @Transactional
    public void excluir(Long id) {
        Curso curso = buscar(id);

        if (matriculaRepository.existsByCurso_IdAndStatus(id, StatusMatricula.ATIVA)) {
            throw new RegraNegocioException(
                    "Curso possui matrículas ativas e não pode ser excluído.");
        }
        if (matriculaRepository.existsByCurso_Id(id)) {
            throw new RegraNegocioException(
                    "Curso possui histórico de matrículas (trancadas, canceladas ou concluídas) "
                            + "e não pode ser excluído para preservar a integridade dos dados acadêmicos.");
        }
        repository.delete(curso);
    }

    private Curso buscar(Long id) {
        return repository.findById(id)
                .orElseThrow(() -> new RecursoNaoEncontradoException("Curso não encontrado."));
    }
}
