package br.edu.univest.academico.service;

import br.edu.univest.academico.exception.RecursoNaoEncontradoException;
import br.edu.univest.academico.exception.RegraNegocioException;
import br.edu.univest.academico.model.Aluno;
import br.edu.univest.academico.model.Curso;
import br.edu.univest.academico.model.Matricula;
import br.edu.univest.academico.model.StatusMatricula;
import br.edu.univest.academico.repository.AlunoRepository;
import br.edu.univest.academico.repository.CursoRepository;
import br.edu.univest.academico.repository.MatriculaRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

/**
 * Camada de negocio das matriculas: orquestra Aluno, Curso e Matricula,
 * aplica as regras do dominio e delimita as transacoes.
 */
@Service
public class MatriculaService {

    private final MatriculaRepository repository;
    private final AlunoRepository alunoRepository;
    private final CursoRepository cursoRepository;

    public MatriculaService(MatriculaRepository repository,
                            AlunoRepository alunoRepository,
                            CursoRepository cursoRepository) {
        this.repository = repository;
        this.alunoRepository = alunoRepository;
        this.cursoRepository = cursoRepository;
    }

    // ------------------------------------------------------------------
    // Consultas (transacao somente leitura)
    // ------------------------------------------------------------------

    @Transactional(readOnly = true)
    public List<Matricula> listar() {
        return repository.findAll();
    }

    @Transactional(readOnly = true)
    public List<Matricula> listarPorAluno(Long alunoId) {
        return repository.findByAluno_Id(alunoId);
    }

    @Transactional(readOnly = true)
    public List<Matricula> listarPorCurso(Long cursoId) {
        return repository.findByCurso_Id(cursoId);
    }

    @Transactional(readOnly = true)
    public Matricula consultar(Long id) {
        return buscarMatricula(id);
    }

    // ------------------------------------------------------------------
    // Matricular (Exercicio 02)
    // ------------------------------------------------------------------

    @Transactional
    public Matricula matricular(Long alunoId, Long cursoId) {
        Aluno aluno = buscarAluno(alunoId);
        Curso curso = buscarCurso(cursoId);
        validarDuplicidade(alunoId, cursoId);

        return repository.save(new Matricula(null, aluno, curso, StatusMatricula.ATIVA));
    }

    /** Atualiza aluno/curso de uma matricula. Somente matriculas ATIVAS podem ser alteradas. */
    @Transactional
    public Matricula atualizar(Long id, Long alunoId, Long cursoId) {
        Matricula matricula = buscarMatricula(id);
        if (matricula.getStatus() != StatusMatricula.ATIVA) {
            throw new RegraNegocioException(
                    "Operação incompatível com o status atual da matrícula: "
                            + "apenas matrículas ATIVA podem ser atualizadas (status atual: "
                            + matricula.getStatus() + ").");
        }
        Aluno aluno = buscarAluno(alunoId);
        Curso curso = buscarCurso(cursoId);

        if (repository.existsByAluno_IdAndCurso_IdAndStatusAndIdNot(
                alunoId, cursoId, StatusMatricula.ATIVA, id)) {
            throw new RegraNegocioException("Aluno já possui matrícula ativa neste curso.");
        }
        matricula.setAluno(aluno);
        matricula.setCurso(curso);
        return matricula; // dirty checking: o UPDATE e gerado no commit
    }

    // ------------------------------------------------------------------
    // Estados da matricula (Exercicios 04 e 06)
    // ------------------------------------------------------------------

    @Transactional
    public Matricula trancarMatricula(Long id) {
        return mudarStatus(id, StatusMatricula.TRANCADA, "trancar");
    }

    @Transactional
    public Matricula cancelarMatricula(Long id) {
        return mudarStatus(id, StatusMatricula.CANCELADA, "cancelar");
    }

    @Transactional
    public Matricula concluirMatricula(Long id) {
        return mudarStatus(id, StatusMatricula.CONCLUIDA, "concluir");
    }

    /**
     * DIRTY CHECKING: a matricula e carregada dentro da transacao (entidade "gerenciada").
     * Ao alterar o status, o Hibernate percebe a diferenca em relacao ao estado original
     * e gera o UPDATE sozinho no commit - por isso NAO ha chamada a repository.save().
     */
    private Matricula mudarStatus(Long id, StatusMatricula novoStatus, String acao) {
        Matricula matricula = buscarMatricula(id);

        if (!matricula.getStatus().podeTransitarPara(novoStatus)) {
            throw new RegraNegocioException(
                    "Operação incompatível com o status atual da matrícula: não é possível "
                            + acao + " uma matrícula com status " + matricula.getStatus()
                            + ". Apenas matrículas ATIVA permitem esta operação.");
        }
        matricula.setStatus(novoStatus);
        return matricula;
    }

    // ------------------------------------------------------------------
    // Transferencia entre cursos (Exercicio 05 - duas alteracoes, uma transacao)
    // ------------------------------------------------------------------

    /**
     * Cancela a matricula atual e cria uma nova ATIVA no novo curso - tudo ou nada.
     *
     * A 1a alteracao (cancelar) e enviada ao banco com saveAndFlush ANTES da validacao de
     * duplicidade. Se a validacao falhar, a RuntimeException dispara ROLLBACK e o
     * cancelamento ja gravado e desfeito. Sem @Transactional, a matricula antiga ficaria
     * cancelada mesmo com a transferencia rejeitada.
     */
    @Transactional
    public Matricula transferir(Long id, Long novoCursoId) {
        Matricula atual = buscarMatricula(id);
        if (atual.getStatus() != StatusMatricula.ATIVA) {
            throw new RegraNegocioException(
                    "Operação incompatível com o status atual da matrícula: "
                            + "apenas matrículas ATIVA podem ser transferidas (status atual: "
                            + atual.getStatus() + ").");
        }
        if (atual.getCurso().getId().equals(novoCursoId)) {
            throw new RegraNegocioException("A matrícula já pertence a este curso.");
        }
        Curso novoCurso = buscarCurso(novoCursoId);

        // 1a alteracao: cancela a matricula atual e forca o UPDATE no banco
        atual.setStatus(StatusMatricula.CANCELADA);
        repository.saveAndFlush(atual);

        // Se aqui lancar excecao -> rollback desfaz o cancelamento acima
        validarDuplicidade(atual.getAluno().getId(), novoCursoId);

        // 2a alteracao: cria a nova matricula
        return repository.save(new Matricula(null, atual.getAluno(), novoCurso, StatusMatricula.ATIVA));
    }

    // ------------------------------------------------------------------
    // Apoio
    // ------------------------------------------------------------------

    private void validarDuplicidade(Long alunoId, Long cursoId) {
        if (repository.existsByAluno_IdAndCurso_IdAndStatus(alunoId, cursoId, StatusMatricula.ATIVA)) {
            throw new RegraNegocioException("Aluno já possui matrícula ativa neste curso.");
        }
    }

    private Matricula buscarMatricula(Long id) {
        return repository.findById(id)
                .orElseThrow(() -> new RecursoNaoEncontradoException("Matrícula não encontrada."));
    }

    private Aluno buscarAluno(Long id) {
        return alunoRepository.findById(id)
                .orElseThrow(() -> new RecursoNaoEncontradoException("Aluno não encontrado."));
    }

    private Curso buscarCurso(Long id) {
        return cursoRepository.findById(id)
                .orElseThrow(() -> new RecursoNaoEncontradoException("Curso não encontrado."));
    }
}
