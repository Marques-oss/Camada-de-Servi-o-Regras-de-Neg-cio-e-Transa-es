package br.edu.univest.academico.service;

import br.edu.univest.academico.exception.RecursoNaoEncontradoException;
import br.edu.univest.academico.exception.RegraNegocioException;
import br.edu.univest.academico.model.Aluno;
import br.edu.univest.academico.model.StatusMatricula;
import br.edu.univest.academico.repository.AlunoRepository;
import br.edu.univest.academico.repository.MatriculaRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
public class AlunoService {

    private final AlunoRepository repository;
    private final MatriculaRepository matriculaRepository;

    public AlunoService(AlunoRepository repository, MatriculaRepository matriculaRepository) {
        this.repository = repository;
        this.matriculaRepository = matriculaRepository;
    }

    @Transactional(readOnly = true)
    public List<Aluno> listar() {
        return repository.findAll();
    }

    @Transactional(readOnly = true)
    public Aluno consultar(Long id) {
        return buscar(id);
    }

    @Transactional
    public Aluno cadastrar(Aluno aluno) {
        if (repository.existsByEmail(aluno.getEmail())) {
            throw new RegraNegocioException("Já existe um aluno cadastrado com este e-mail.");
        }
        return repository.save(aluno);
    }

    @Transactional
    public Aluno atualizar(Long id, Aluno dados) {
        Aluno existente = buscar(id);
        if (repository.existsByEmailAndIdNot(dados.getEmail(), id)) {
            throw new RegraNegocioException("Já existe outro aluno cadastrado com este e-mail.");
        }
        // Entidade gerenciada: basta alterar os atributos (dirty checking gera o UPDATE no commit).
        existente.setNome(dados.getNome());
        existente.setEmail(dados.getEmail());
        existente.setIdade(dados.getIdade());
        return existente;
    }

    @Transactional
    public void excluir(Long id) {
        Aluno aluno = buscar(id);

        if (matriculaRepository.existsByAluno_IdAndStatus(id, StatusMatricula.ATIVA)) {
            throw new RegraNegocioException(
                    "Aluno possui matrícula ativa e não pode ser excluído. Cancele ou conclua a matrícula antes.");
        }
        // Regra de integridade: a FK impediria o DELETE; antecipamos com mensagem clara.
        if (matriculaRepository.existsByAluno_Id(id)) {
            throw new RegraNegocioException(
                    "Aluno possui histórico de matrículas (trancadas, canceladas ou concluídas) "
                            + "e não pode ser excluído para preservar a integridade dos dados acadêmicos.");
        }
        repository.delete(aluno);
    }

    private Aluno buscar(Long id) {
        return repository.findById(id)
                .orElseThrow(() -> new RecursoNaoEncontradoException("Aluno não encontrado."));
    }
}
