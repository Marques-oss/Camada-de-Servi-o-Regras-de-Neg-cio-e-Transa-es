package br.edu.univest.academico.exception;

import java.time.LocalDateTime;
import java.util.Map;

/** Corpo da resposta 400 quando o @Valid reprova o payload (Semana 04). */
public class ErroValidacaoDTO {

    private final LocalDateTime timestamp = LocalDateTime.now();
    private final int status;
    private final String erro;
    private final Map<String, String> campos;

    public ErroValidacaoDTO(int status, String erro, Map<String, String> campos) {
        this.status = status;
        this.erro = erro;
        this.campos = campos;
    }

    public LocalDateTime getTimestamp() { return timestamp; }
    public int getStatus() { return status; }
    public String getErro() { return erro; }
    public Map<String, String> getCampos() { return campos; }
}
