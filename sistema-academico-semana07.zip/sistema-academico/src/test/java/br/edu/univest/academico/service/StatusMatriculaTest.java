package br.edu.univest.academico.service;

import br.edu.univest.academico.model.StatusMatricula;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

/** Tabela de transicoes do Exercicio 04: so ATIVA pode mudar de estado. */
class StatusMatriculaTest {

    @Test
    void ativaPodeIrParaTrancadaCanceladaEConcluida() {
        assertTrue(StatusMatricula.ATIVA.podeTransitarPara(StatusMatricula.TRANCADA));
        assertTrue(StatusMatricula.ATIVA.podeTransitarPara(StatusMatricula.CANCELADA));
        assertTrue(StatusMatricula.ATIVA.podeTransitarPara(StatusMatricula.CONCLUIDA));
    }

    @Test
    void ativaNaoTransitaParaAtiva() {
        assertFalse(StatusMatricula.ATIVA.podeTransitarPara(StatusMatricula.ATIVA));
    }

    @Test
    void estadosFinaisOuInativosNaoTransitam() {
        for (StatusMatricula origem : new StatusMatricula[]{
                StatusMatricula.TRANCADA, StatusMatricula.CANCELADA, StatusMatricula.CONCLUIDA}) {
            for (StatusMatricula destino : StatusMatricula.values()) {
                assertFalse(origem.podeTransitarPara(destino),
                        origem + " não deveria transitar para " + destino);
            }
        }
    }
}
