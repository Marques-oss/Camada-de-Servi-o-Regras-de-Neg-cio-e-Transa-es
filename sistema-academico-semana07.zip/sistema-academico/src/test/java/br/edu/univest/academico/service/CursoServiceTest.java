package br.edu.univest.academico.service;

import br.edu.univest.academico.exception.RecursoNaoEncontradoException;
import br.edu.univest.academico.exception.RegraNegocioException;
import br.edu.univest.academico.model.Curso;
import br.edu.univest.academico.model.StatusMatricula;
import br.edu.univest.academico.repository.CursoRepository;
import br.edu.univest.academico.repository.MatriculaRepository;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class CursoServiceTest {

    @Mock
    private CursoRepository repository;
    @Mock
    private MatriculaRepository matriculaRepository;

    @InjectMocks
    private CursoService service;

    private Curso curso(Long id) {
        Curso c = new Curso();
        c.setId(id);
        c.setNome("Análise e Desenvolvimento de Sistemas");
        c.setCargaHoraria(2400);
        return c;
    }

    @Test
    @DisplayName("Excluir curso com matrícula ativa -> exceção e nada é excluído")
    void excluir_comMatriculaAtiva() {
        when(repository.findById(2L)).thenReturn(Optional.of(curso(2L)));
        when(matriculaRepository.existsByCurso_IdAndStatus(2L, StatusMatricula.ATIVA)).thenReturn(true);

        RegraNegocioException ex = assertThrows(RegraNegocioException.class, () -> service.excluir(2L));

        assertTrue(ex.getMessage().contains("matrículas ativas"));
        verify(repository, never()).delete(any(Curso.class));
    }

    @Test
    @DisplayName("Excluir curso apenas com histórico de matrículas -> exceção")
    void excluir_comHistorico() {
        when(repository.findById(2L)).thenReturn(Optional.of(curso(2L)));
        when(matriculaRepository.existsByCurso_IdAndStatus(2L, StatusMatricula.ATIVA)).thenReturn(false);
        when(matriculaRepository.existsByCurso_Id(2L)).thenReturn(true);

        assertThrows(RegraNegocioException.class, () -> service.excluir(2L));
        verify(repository, never()).delete(any(Curso.class));
    }

    @Test
    @DisplayName("Excluir curso sem matrículas -> permitido")
    void excluir_semMatriculas() {
        Curso c = curso(2L);
        when(repository.findById(2L)).thenReturn(Optional.of(c));
        when(matriculaRepository.existsByCurso_IdAndStatus(2L, StatusMatricula.ATIVA)).thenReturn(false);
        when(matriculaRepository.existsByCurso_Id(2L)).thenReturn(false);

        service.excluir(2L);

        verify(repository).delete(c);
    }

    @Test
    @DisplayName("Excluir curso inexistente -> exceção de recurso não encontrado")
    void excluir_inexistente() {
        when(repository.findById(99L)).thenReturn(Optional.empty());

        assertThrows(RecursoNaoEncontradoException.class, () -> service.excluir(99L));
    }
}
