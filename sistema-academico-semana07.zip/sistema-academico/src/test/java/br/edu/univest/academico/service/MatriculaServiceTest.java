package br.edu.univest.academico.service;

import br.edu.univest.academico.exception.RecursoNaoEncontradoException;
import br.edu.univest.academico.exception.RegraNegocioException;
import br.edu.univest.academico.model.Aluno;
import br.edu.univest.academico.model.Curso;
import br.edu.univest.academico.model.Matricula;
import br.edu.univest.academico.model.StatusMatricula;
import br.edu.univest.academico.repository.AlunoRepository;
import br.edu.univest.academico.repository.CursoRepository;
import br.edu.univest.academico.repository.MatriculaRepository;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoInteractions;
import static org.mockito.Mockito.when;

/**
 * Testes unitarios das regras de negocio de matricula.
 * As dependencias (repositories) sao mocks: nenhum banco e necessario.
 */
@ExtendWith(MockitoExtension.class)
class MatriculaServiceTest {

    @Mock
    private MatriculaRepository repository;
    @Mock
    private AlunoRepository alunoRepository;
    @Mock
    private CursoRepository cursoRepository;

    @InjectMocks
    private MatriculaService service;

    // ---------- helpers ----------

    private Aluno aluno(Long id) {
        Aluno a = new Aluno();
        a.setId(id);
        a.setNome("Ana Souza");
        a.setEmail("ana@email.com");
        a.setIdade(20);
        return a;
    }

    private Curso curso(Long id, String nome) {
        Curso c = new Curso();
        c.setId(id);
        c.setNome(nome);
        c.setCargaHoraria(3200);
        return c;
    }

    private Matricula matricula(Long id, StatusMatricula status) {
        return new Matricula(id, aluno(1L), curso(2L, "Análise e Desenvolvimento de Sistemas"), status);
    }

    // ---------- matricular (Exercicio 02) ----------

    @Test
    @DisplayName("Aluno e curso existentes -> matrícula criada com status ATIVA")
    void matricular_criaMatriculaAtiva() {
        Aluno a = aluno(1L);
        Curso c = curso(2L, "ADS");
        when(alunoRepository.findById(1L)).thenReturn(Optional.of(a));
        when(cursoRepository.findById(2L)).thenReturn(Optional.of(c));
        when(repository.existsByAluno_IdAndCurso_IdAndStatus(1L, 2L, StatusMatricula.ATIVA)).thenReturn(false);
        when(repository.save(any(Matricula.class))).thenAnswer(inv -> inv.getArgument(0));

        Matricula resultado = service.matricular(1L, 2L);

        assertEquals(StatusMatricula.ATIVA, resultado.getStatus());
        assertSame(a, resultado.getAluno());
        assertSame(c, resultado.getCurso());
        verify(repository).save(any(Matricula.class));
    }

    @Test
    @DisplayName("Aluno inexistente -> exceção e nada é salvo")
    void matricular_alunoInexistente_lancaExcecao() {
        when(alunoRepository.findById(99L)).thenReturn(Optional.empty());

        RecursoNaoEncontradoException ex = assertThrows(RecursoNaoEncontradoException.class,
                () -> service.matricular(99L, 2L));

        assertEquals("Aluno não encontrado.", ex.getMessage());
        verifyNoInteractions(cursoRepository);
        verify(repository, never()).save(any(Matricula.class));
    }

    @Test
    @DisplayName("Curso inexistente -> exceção e nada é salvo")
    void matricular_cursoInexistente_lancaExcecao() {
        when(alunoRepository.findById(1L)).thenReturn(Optional.of(aluno(1L)));
        when(cursoRepository.findById(99L)).thenReturn(Optional.empty());

        RecursoNaoEncontradoException ex = assertThrows(RecursoNaoEncontradoException.class,
                () -> service.matricular(1L, 99L));

        assertEquals("Curso não encontrado.", ex.getMessage());
        verify(repository, never()).save(any(Matricula.class));
    }

    @Test
    @DisplayName("Matrícula ativa duplicada -> operação rejeitada")
    void matricular_duplicada_lancaExcecao() {
        when(alunoRepository.findById(1L)).thenReturn(Optional.of(aluno(1L)));
        when(cursoRepository.findById(2L)).thenReturn(Optional.of(curso(2L, "ADS")));
        when(repository.existsByAluno_IdAndCurso_IdAndStatus(1L, 2L, StatusMatricula.ATIVA)).thenReturn(true);

        RegraNegocioException ex = assertThrows(RegraNegocioException.class,
                () -> service.matricular(1L, 2L));

        assertTrue(ex.getMessage().contains("matrícula ativa"));
        verify(repository, never()).save(any(Matricula.class));
    }

    // ---------- estados (Exercicios 04 e 06) ----------

    @Test
    @DisplayName("Trancamento válido -> status TRANCADA (sem chamar save: dirty checking)")
    void trancar_valido() {
        Matricula m = matricula(10L, StatusMatricula.ATIVA);
        when(repository.findById(10L)).thenReturn(Optional.of(m));

        Matricula resultado = service.trancarMatricula(10L);

        assertEquals(StatusMatricula.TRANCADA, resultado.getStatus());
        verify(repository, never()).save(any(Matricula.class));
    }

    @Test
    @DisplayName("Trancar matrícula CONCLUIDA -> exceção")
    void trancar_invalido() {
        Matricula m = matricula(10L, StatusMatricula.CONCLUIDA);
        when(repository.findById(10L)).thenReturn(Optional.of(m));

        assertThrows(RegraNegocioException.class, () -> service.trancarMatricula(10L));
        assertEquals(StatusMatricula.CONCLUIDA, m.getStatus());
    }

    @Test
    @DisplayName("Cancelamento válido -> status CANCELADA")
    void cancelar_valido() {
        Matricula m = matricula(10L, StatusMatricula.ATIVA);
        when(repository.findById(10L)).thenReturn(Optional.of(m));

        Matricula resultado = service.cancelarMatricula(10L);

        assertEquals(StatusMatricula.CANCELADA, resultado.getStatus());
    }

    @Test
    @DisplayName("Cancelar matrícula TRANCADA -> exceção")
    void cancelar_invalido() {
        Matricula m = matricula(10L, StatusMatricula.TRANCADA);
        when(repository.findById(10L)).thenReturn(Optional.of(m));

        RegraNegocioException ex = assertThrows(RegraNegocioException.class,
                () -> service.cancelarMatricula(10L));

        assertTrue(ex.getMessage().contains("TRANCADA"));
        assertEquals(StatusMatricula.TRANCADA, m.getStatus());
    }

    @Test
    @DisplayName("Conclusão válida -> status CONCLUIDA")
    void concluir_valido() {
        Matricula m = matricula(10L, StatusMatricula.ATIVA);
        when(repository.findById(10L)).thenReturn(Optional.of(m));

        Matricula resultado = service.concluirMatricula(10L);

        assertEquals(StatusMatricula.CONCLUIDA, resultado.getStatus());
    }

    @Test
    @DisplayName("Concluir matrícula CANCELADA -> exceção")
    void concluir_invalido() {
        Matricula m = matricula(10L, StatusMatricula.CANCELADA);
        when(repository.findById(10L)).thenReturn(Optional.of(m));

        assertThrows(RegraNegocioException.class, () -> service.concluirMatricula(10L));
        assertEquals(StatusMatricula.CANCELADA, m.getStatus());
    }

    @Test
    @DisplayName("Operar sobre matrícula inexistente -> exceção de recurso não encontrado")
    void trancar_matriculaInexistente() {
        when(repository.findById(5L)).thenReturn(Optional.empty());

        RecursoNaoEncontradoException ex = assertThrows(RecursoNaoEncontradoException.class,
                () -> service.trancarMatricula(5L));

        assertEquals("Matrícula não encontrada.", ex.getMessage());
    }

    // ---------- atualizar ----------

    @Test
    @DisplayName("Atualizar matrícula ATIVA -> troca aluno/curso")
    void atualizar_valido() {
        Matricula m = matricula(10L, StatusMatricula.ATIVA);
        Aluno novoAluno = aluno(1L);
        Curso novoCurso = curso(3L, "Ciência da Computação");
        when(repository.findById(10L)).thenReturn(Optional.of(m));
        when(alunoRepository.findById(1L)).thenReturn(Optional.of(novoAluno));
        when(cursoRepository.findById(3L)).thenReturn(Optional.of(novoCurso));
        when(repository.existsByAluno_IdAndCurso_IdAndStatusAndIdNot(1L, 3L, StatusMatricula.ATIVA, 10L))
                .thenReturn(false);

        Matricula resultado = service.atualizar(10L, 1L, 3L);

        assertSame(novoCurso, resultado.getCurso());
        assertSame(novoAluno, resultado.getAluno());
    }

    @Test
    @DisplayName("Atualizar matrícula TRANCADA -> exceção (operação incompatível com o status)")
    void atualizar_matriculaNaoAtiva() {
        Matricula m = matricula(10L, StatusMatricula.TRANCADA);
        when(repository.findById(10L)).thenReturn(Optional.of(m));

        assertThrows(RegraNegocioException.class, () -> service.atualizar(10L, 1L, 3L));
        verifyNoInteractions(alunoRepository, cursoRepository);
    }

    // ---------- transferir (Exercicio 05) ----------

    @Test
    @DisplayName("Transferência válida -> cancela a atual e cria nova ATIVA no novo curso")
    void transferir_valido() {
        Matricula atual = matricula(10L, StatusMatricula.ATIVA);
        Curso novoCurso = curso(3L, "Ciência da Computação");
        when(repository.findById(10L)).thenReturn(Optional.of(atual));
        when(cursoRepository.findById(3L)).thenReturn(Optional.of(novoCurso));
        when(repository.existsByAluno_IdAndCurso_IdAndStatus(1L, 3L, StatusMatricula.ATIVA)).thenReturn(false);
        when(repository.save(any(Matricula.class))).thenAnswer(inv -> inv.getArgument(0));

        Matricula nova = service.transferir(10L, 3L);

        assertEquals(StatusMatricula.CANCELADA, atual.getStatus());
        assertEquals(StatusMatricula.ATIVA, nova.getStatus());
        assertSame(novoCurso, nova.getCurso());
        verify(repository).saveAndFlush(atual);
    }

    @Test
    @DisplayName("Transferência para curso em que já há matrícula ativa -> exceção (o rollback desfaz o cancelamento)")
    void transferir_duplicada_lancaExcecao() {
        Matricula atual = matricula(10L, StatusMatricula.ATIVA);
        when(repository.findById(10L)).thenReturn(Optional.of(atual));
        when(cursoRepository.findById(3L)).thenReturn(Optional.of(curso(3L, "Ciência da Computação")));
        when(repository.existsByAluno_IdAndCurso_IdAndStatus(1L, 3L, StatusMatricula.ATIVA)).thenReturn(true);

        assertThrows(RegraNegocioException.class, () -> service.transferir(10L, 3L));

        // A 1a alteracao chegou a ser enviada ao banco; em producao o @Transactional faz o rollback.
        verify(repository).saveAndFlush(atual);
        verify(repository, never()).save(any(Matricula.class));
    }

    @Test
    @DisplayName("Transferir para o mesmo curso -> exceção")
    void transferir_mesmoCurso() {
        Matricula atual = matricula(10L, StatusMatricula.ATIVA); // curso 2
        when(repository.findById(10L)).thenReturn(Optional.of(atual));

        assertThrows(RegraNegocioException.class, () -> service.transferir(10L, 2L));
        verifyNoInteractions(cursoRepository);
    }

    @Test
    @DisplayName("Transferir matrícula CANCELADA -> exceção")
    void transferir_matriculaNaoAtiva() {
        Matricula atual = matricula(10L, StatusMatricula.CANCELADA);
        when(repository.findById(10L)).thenReturn(Optional.of(atual));

        assertThrows(RegraNegocioException.class, () -> service.transferir(10L, 3L));
        verify(repository, never()).saveAndFlush(any(Matricula.class));
    }
}
