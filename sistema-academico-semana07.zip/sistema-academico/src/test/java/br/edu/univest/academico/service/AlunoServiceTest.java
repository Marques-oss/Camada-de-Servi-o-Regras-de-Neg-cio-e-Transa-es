package br.edu.univest.academico.service;

import br.edu.univest.academico.exception.RecursoNaoEncontradoException;
import br.edu.univest.academico.exception.RegraNegocioException;
import br.edu.univest.academico.model.Aluno;
import br.edu.univest.academico.model.StatusMatricula;
import br.edu.univest.academico.repository.AlunoRepository;
import br.edu.univest.academico.repository.MatriculaRepository;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class AlunoServiceTest {

    @Mock
    private AlunoRepository repository;
    @Mock
    private MatriculaRepository matriculaRepository;

    @InjectMocks
    private AlunoService service;

    private Aluno aluno(Long id) {
        Aluno a = new Aluno();
        a.setId(id);
        a.setNome("Ana Souza");
        a.setEmail("ana@email.com");
        a.setIdade(20);
        return a;
    }

    @Test
    @DisplayName("Excluir aluno com matrícula ativa -> exceção e nada é excluído")
    void excluir_comMatriculaAtiva() {
        when(repository.findById(1L)).thenReturn(Optional.of(aluno(1L)));
        when(matriculaRepository.existsByAluno_IdAndStatus(1L, StatusMatricula.ATIVA)).thenReturn(true);

        RegraNegocioException ex = assertThrows(RegraNegocioException.class, () -> service.excluir(1L));

        assertTrue(ex.getMessage().contains("matrícula ativa"));
        verify(repository, never()).delete(any(Aluno.class));
    }

    @Test
    @DisplayName("Excluir aluno apenas com histórico de matrículas -> exceção (integridade referencial)")
    void excluir_comHistorico() {
        when(repository.findById(1L)).thenReturn(Optional.of(aluno(1L)));
        when(matriculaRepository.existsByAluno_IdAndStatus(1L, StatusMatricula.ATIVA)).thenReturn(false);
        when(matriculaRepository.existsByAluno_Id(1L)).thenReturn(true);

        RegraNegocioException ex = assertThrows(RegraNegocioException.class, () -> service.excluir(1L));

        assertTrue(ex.getMessage().contains("histórico"));
        verify(repository, never()).delete(any(Aluno.class));
    }

    @Test
    @DisplayName("Excluir aluno sem matrículas -> permitido")
    void excluir_semMatriculas() {
        Aluno a = aluno(1L);
        when(repository.findById(1L)).thenReturn(Optional.of(a));
        when(matriculaRepository.existsByAluno_IdAndStatus(1L, StatusMatricula.ATIVA)).thenReturn(false);
        when(matriculaRepository.existsByAluno_Id(1L)).thenReturn(false);

        service.excluir(1L);

        verify(repository).delete(a);
    }

    @Test
    @DisplayName("Excluir aluno inexistente -> exceção de recurso não encontrado")
    void excluir_inexistente() {
        when(repository.findById(99L)).thenReturn(Optional.empty());

        assertThrows(RecursoNaoEncontradoException.class, () -> service.excluir(99L));
    }

    @Test
    @DisplayName("Cadastrar aluno com e-mail já usado -> exceção")
    void cadastrar_emailDuplicado() {
        Aluno novo = aluno(null);
        when(repository.existsByEmail("ana@email.com")).thenReturn(true);

        assertThrows(RegraNegocioException.class, () -> service.cadastrar(novo));
        verify(repository, never()).save(any(Aluno.class));
    }

    @Test
    @DisplayName("Cadastrar aluno com e-mail livre -> salvo")
    void cadastrar_valido() {
        Aluno novo = aluno(null);
        when(repository.existsByEmail("ana@email.com")).thenReturn(false);
        when(repository.save(novo)).thenReturn(novo);

        assertSame(novo, service.cadastrar(novo));
    }

    @Test
    @DisplayName("Atualizar aluno com e-mail de outro aluno -> exceção")
    void atualizar_emailDeOutroAluno() {
        when(repository.findById(1L)).thenReturn(Optional.of(aluno(1L)));
        when(repository.existsByEmailAndIdNot("ana@email.com", 1L)).thenReturn(true);

        assertThrows(RegraNegocioException.class, () -> service.atualizar(1L, aluno(null)));
    }
}
