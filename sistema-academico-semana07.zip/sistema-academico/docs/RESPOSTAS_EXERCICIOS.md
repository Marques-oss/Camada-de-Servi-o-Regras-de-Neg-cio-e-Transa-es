# Respostas dos exercícios — Aula 07

## Exercício 01 — Separação de responsabilidades

**Responsabilidades**

| Camada | Responsabilidade |
|--------|------------------|
| Controller | Receber a requisição HTTP, validar o DTO (`@Valid`), delegar ao Service e definir o status HTTP |
| Service | Aplicar regras de negócio, coordenar Repositories e delimitar a transação |
| Repository | Consultas e persistência (`JpaRepository`), sem regra de negócio |

**Por que regras de negócio não ficam no Controller?** O Controller é a fronteira HTTP. Se ele guardar regras, elas não podem ser reaproveitadas por outras entradas (outro endpoint, rotina agendada, mensageria), ficam difíceis de testar sem subir a camada web e o código vira um bloco misturado de HTTP com domínio.

**Quem verifica se o aluno já tem matrícula ativa no curso?** O **Service** (`MatriculaService.validarDuplicidade`), usando o Repository para consultar (`existsByAluno_IdAndCurso_IdAndStatus`). O Repository só responde "existe?"; a decisão de rejeitar é regra de negócio.

**Fluxo de uma matrícula, do HTTP ao banco**

```
POST /api/matriculas  { "alunoId": 1, "cursoId": 2 }
        │
        ▼
MatriculaController   valida o MatriculaRequestDTO (@Valid)
        │
        ▼
MatriculaService  (@Transactional)
        ├─► AlunoRepository.findById   → 404 se não existir
        ├─► CursoRepository.findById   → 404 se não existir
        ├─► MatriculaRepository.existsBy...  → 422 se já houver ATIVA
        └─► MatriculaRepository.save(new Matricula(aluno, curso, ATIVA))
        │
        ▼
JPA / Hibernate  →  INSERT INTO tb_matricula ...  →  PostgreSQL (FKs + índice único)
        │
        ▼
COMMIT  →  Controller converte para MatriculaResponseDTO  →  201 Created
```

## Exercício 05 — Transações com `@Transactional`

**Objetivo:** fazer um conjunto de operações valer como uma unidade: ou todas são confirmadas (*commit*) ou todas são desfeitas (*rollback*). Isso garante atomicidade e evita dados pela metade.

**Onde foi aplicado:** em todos os métodos de escrita dos Services; leituras usam `@Transactional(readOnly = true)`. O caso demonstrativo é `MatriculaService.transferir`, que cancela uma matrícula e cria outra.

**Simulação de exceção:** em `transferir`, o cancelamento é enviado ao banco (`saveAndFlush`) e só depois a duplicidade no curso de destino é verificada. Se houver matrícula ativa no destino, uma `RegraNegocioException` (não verificada, `RuntimeException`) é lançada.

**Resultado esperado:** o Spring faz *rollback* e a matrícula original volta a ficar `ATIVA` (passo a passo no README, seção "Como verificar o rollback").

**Commit x Rollback**
- **Commit:** a operação terminou sem erro; as alterações são gravadas definitivamente.
- **Rollback:** houve falha (por padrão, uma exceção não verificada); todas as alterações da transação são desfeitas.

## Exercício 06 — Dirty checking

`MatriculaService.mudarStatus`: consulta a matrícula pelo id, verifica se a transição é permitida (`StatusMatricula.podeTransitarPara`), altera `status` e retorna — **sem chamar `save()`**.

**Por que o JPA atualiza sozinho?** Dentro de uma transação, a entidade carregada fica *gerenciada* pelo contexto de persistência, que guarda uma cópia do estado original. No commit (flush), o Hibernate compara o estado atual com o original; se detecta diferença (*dirty checking*), gera o `UPDATE` automaticamente. Fora de uma transação a entidade fica *desanexada* e a alteração não seria persistida — por isso o método é `@Transactional`.

Os testes unitários confirmam que `save()` não é chamado nessas operações (`verify(repository, never()).save(...)`).
