# Sistema de Gerenciamento Acadêmico (SGA) — Programação Web II

Projeto integrador da disciplina **Programação Web II** (Univest), construído de forma incremental ao longo das semanas:

| Semana | Tema | O que está no projeto |
|--------|------|------------------------|
| 03 | API RESTful | Controllers, `ResponseEntity`, Swagger/OpenAPI |
| 04 | DTOs e Validação | `RequestDTO`/`ResponseDTO`, `@Valid`, Jakarta Validation |
| 05 | Spring Data JPA + Flyway | Entidades, Repositories, PostgreSQL, migrations |
| 06 | Relacionamentos JPA | `@ManyToOne`, `@OneToMany`, `@JoinColumn`, chaves estrangeiras |
| 07 | Service, regras e transações | Regras de negócio, exceções, `@Transactional`, dirty checking, testes |

## Tecnologias

Java 17 · Spring Boot 3.3.4 · Spring Web · Spring Data JPA (Hibernate) · PostgreSQL 16 · Flyway · Jakarta Validation · springdoc-openapi (Swagger UI) · JUnit 5 + Mockito · Maven

## Arquitetura

```
Cliente
   │  JSON
   ▼
RequestDTO ──► Controller ──► Service ──► Repository ──► JPA/Hibernate ──► PostgreSQL
(validação)    (HTTP, status)  (regras +    (consultas)                      (integridade,
                                transações)                                   FKs, índices)
```

- **Controller**: recebe HTTP, valida o DTO com `@Valid`, delega ao Service e define o status. Não acessa Repository.
- **Service**: regras de negócio, exceções de domínio e fronteira transacional (`@Transactional`).
- **Repository**: acesso a dados (`JpaRepository`), sem regra de negócio.
- **Banco**: schema versionado pelo Flyway; chaves estrangeiras e índice único protegem a integridade.

```
src/main/java/br/edu/univest/academico
 ├── controller   AlunoController, CursoController, MatriculaController
 ├── service      AlunoService, CursoService, MatriculaService
 ├── repository   AlunoRepository, CursoRepository, MatriculaRepository, UsuarioRepository
 ├── model        Aluno, Curso, Matricula, Usuario, StatusMatricula (enum)
 ├── dto          Request/Response DTOs e Mappers
 └── exception    RegraNegocioException, RecursoNaoEncontradoException, GlobalExceptionHandler
src/main/resources/db/migration   V1 ... V7 (Flyway)
src/test/java/.../service         testes unitários (JUnit 5 + Mockito)
```

## Como executar

**Pré-requisitos:** Java 17+, Maven 3.9+ (ou VS Code com *Extension Pack for Java*) e um PostgreSQL.

### 1. Subir o PostgreSQL

Opção A — Docker (recomendado; já cria o banco `sistema_academico`):

```bash
docker compose up -d
```

Opção B — PostgreSQL instalado na máquina: crie o banco manualmente.

```sql
CREATE DATABASE sistema_academico;
```

As credenciais padrão (usuário `postgres`, senha `postgres`, `localhost:5432`) estão em
`src/main/resources/application.properties` e podem ser trocadas com as variáveis de ambiente
`DB_URL`, `DB_USER` e `DB_PASSWORD`.

### 2. Rodar a aplicação

```bash
mvn spring-boot:run
```

Ao subir, o **Flyway aplica automaticamente as migrations V1 a V7**. Para conferir:

```sql
SELECT version, description, success FROM flyway_schema_history;
```

- API: http://localhost:8080
- Swagger UI: http://localhost:8080/swagger-ui.html

### 3. Rodar os testes unitários (não precisam de banco)

```bash
mvn test
```

## Migrations (Flyway)

| Versão | Arquivo | Conteúdo |
|--------|---------|----------|
| V1 | `criar_tabela_aluno` | `tb_aluno` |
| V2 | `criar_tabela_curso` | `tb_curso` |
| V3 | `criar_tabela_usuario` | `tb_usuario` |
| V4 | `criar_tabela_matricula` | `tb_matricula` (com `aluno_id` e `curso_id`) |
| V5 | `adicionar_foreign_keys_matricula` | `fk_matricula_aluno`, `fk_matricula_curso` |
| V6 | `adicionar_idade_aluno` | mantém o campo `idade` da Semana 04 sem editar a V1 |
| V7 | `indice_unico_matricula_ativa` | índice único parcial: 1 matrícula ATIVA por aluno/curso |

Nenhuma migration aplicada é editada: toda mudança de schema gera uma nova versão.

## Endpoints

### Alunos — `/api/alunos`
| Método | Rota | Descrição |
|--------|------|-----------|
| GET | `/api/alunos` | Lista alunos |
| GET | `/api/alunos/{id}` | Consulta por ID |
| POST | `/api/alunos` | Cadastra (201) |
| PUT | `/api/alunos/{id}` | Atualiza |
| DELETE | `/api/alunos/{id}` | Exclui (204) — bloqueado se houver matrículas |

### Cursos — `/api/cursos`
Mesmas operações de Alunos.

### Matrículas — `/api/matriculas`
| Método | Rota | Descrição |
|--------|------|-----------|
| GET | `/api/matriculas?alunoId=&cursoId=` | Lista (filtros opcionais) |
| GET | `/api/matriculas/{id}` | Consulta por ID |
| POST | `/api/matriculas` | Matricula aluno em curso (nasce **ATIVA**) |
| PUT | `/api/matriculas/{id}` | Atualiza aluno/curso (somente matrícula ATIVA) |
| PATCH | `/api/matriculas/{id}/trancar` | ATIVA → TRANCADA |
| PATCH | `/api/matriculas/{id}/cancelar` | ATIVA → CANCELADA |
| PATCH | `/api/matriculas/{id}/concluir` | ATIVA → CONCLUIDA |
| POST | `/api/matriculas/{id}/transferir` | Cancela a atual e cria nova em outro curso (transação) |

### Exemplos

```json
POST /api/alunos
{ "nome": "Ana Souza", "email": "ana@email.com", "idade": 22 }

POST /api/cursos
{ "nome": "Análise e Desenvolvimento de Sistemas", "cargaHoraria": 2400 }

POST /api/matriculas
{ "alunoId": 1, "cursoId": 1 }
```

Resposta de uma matrícula:

```json
{
  "id": 1,
  "alunoId": 1,
  "alunoNome": "Ana Souza",
  "cursoId": 1,
  "cursoNome": "Análise e Desenvolvimento de Sistemas",
  "status": "ATIVA"
}
```

## Regras de negócio

1. Só é possível matricular aluno **e** curso que existem (senão 404).
2. Um aluno não pode ter duas matrículas **ATIVAS** no mesmo curso (422; o índice único V7 protege contra requisições simultâneas).
3. Toda matrícula nasce com status **ATIVA**.
4. Transições de estado: somente `ATIVA → TRANCADA | CANCELADA | CONCLUIDA`. Qualquer outra gera exceção de negócio.
5. Não é possível excluir aluno ou curso com matrícula **ativa**; também não se exclui quem tem **histórico** de matrículas (integridade referencial).
6. E-mail de aluno é único.

## Códigos HTTP

| Situação | Status |
|----------|--------|
| Consulta / atualização com sucesso | 200 |
| Criação | 201 |
| Exclusão | 204 |
| Payload inválido (`@Valid`) ou valor de enum desconhecido | 400 |
| Aluno/curso/matrícula inexistente | 404 |
| Regra de negócio violada | 422 |
| Violação de restrição do banco (UNIQUE/FK) | 409 |

Exemplo de erro de validação (400):

```json
{
  "status": 400,
  "erro": "Erro de validação nos dados enviados",
  "campos": { "nome": "O nome deve ter entre 3 e 100 caracteres", "idade": "A idade mínima para matrícula é 16 anos" }
}
```

## Como verificar o rollback (`@Transactional`)

O método `transferir` faz **duas alterações**: cancela a matrícula atual e cria uma nova em outro curso.

1. Crie 1 aluno e 2 cursos.
2. `POST /api/matriculas` → aluno 1 no curso 1 (matrícula 1).
3. `POST /api/matriculas` → aluno 1 no curso 2 (matrícula 2).
4. `POST /api/matriculas/1/transferir` com `{ "novoCursoId": 2 }` → **422** (já existe matrícula ativa no curso 2).
5. `GET /api/matriculas/1` → continua **ATIVA**. O cancelamento já havia sido enviado ao banco (`saveAndFlush`), mas o **rollback** o desfez.

Sem `@Transactional`, a matrícula 1 ficaria CANCELADA mesmo com a transferência rejeitada.

## Respostas teóricas dos exercícios

Veja [`docs/RESPOSTAS_EXERCICIOS.md`](docs/RESPOSTAS_EXERCICIOS.md) (separação de camadas, `@Transactional`, commit x rollback e dirty checking).

## Autor

Allan Vinicios Marques Ferreira — Tecnólogo em Análise e Desenvolvimento de Sistemas / Univest.
